var express = require('express');
var app = express();
const bodyParser = require("body-parser");
var getIP = require('ipware')().get_ip;

var http = require("http");
const contact_conn = require("./confige/contact.confige.js");
const axios = require("axios");



app.listen(80, () => {
  console.log("Server is running on port 3000.");
});





    app.get("/email/open/:con_id/:lst_name/:camp_name", (req, res) => {


req_data={};


req_data.tbl_name=req.params.lst_name;
req_data.con_id=req.params.con_id;
req_data.update_fld=req.params.camp_name;
req_data.update_tag=2;


update_fld_of_db(req_data,function(res2){


console.log(res2);






});

req_of_isrt_data={};


var ipInfo = req.connection.remoteAddress;


req_of_isrt_data.con_id=req.params.con_id;
req_of_isrt_data.act_flg=2;
req_of_isrt_data.ip=ipInfo;


req_of_isrt_data.tbl_name=req.params.camp_name+"#"+req.params.lst_name;


isrt_in_ana_db(req_of_isrt_data,req,function(){






console.log("insert successfull");

})
 setTimeout(function () {
    res.redirect("https://upload.wikimedia.org/wikipedia/commons/c/ca/1x1.png");
}, 500)
});









app.get("/email/click/:con_id/:lst_name/:camp_name/:flg_data", (req, res) => {







const axios = require('axios');




	req_of_isrt_data={};


var ipInfo = req.connection.remoteAddress;


req_of_isrt_data.con_id=req.params.con_id;
req_of_isrt_data.act_flg=2;
req_of_isrt_data.ip=ipInfo;


req_of_isrt_data.tbl_name=req.params.camp_name+"#"+req.params.lst_name;


link_red_url="";



	isrt_in_ana_db(req_of_isrt_data,req,function(res_id){


console.log("check open id"+res_id);


req_data={};


req_data.tbl_name=req.params.lst_name;
req_data.con_id=req.params.con_id;
req_data.update_fld=req.params.camp_name;
req_data.update_tag=req.params.flg_data;





update_fld_of_db(req_data,function(res2){



	console.log("inner click loop");
console.log(res2);






});

req_of_isrt_data={};

const RequestIp = require('@supercharge/request-ip')
var ipInfo =RequestIp.getClientIp(req);

console.log(ipInfo);

req_of_isrt_data.con_id=req.params.con_id;
req_of_isrt_data.act_flg=req.params.flg_data;
req_of_isrt_data.ip=ipInfo;

req_of_isrt_data.tbl_name=req.params.camp_name+"#"+req.params.lst_name;
req_of_isrt_data.url_id=req.params.camp_name+"@"+req.params.flg_data;




isrt_in_ana_db(req_of_isrt_data,req,function(res_id){

req_for_redirect={};

req_for_redirect.match_fld="url_id";
req_for_redirect.get_fld="url";
	req_for_redirect.url_id=res_id;
	req_for_redirect.tbl_name="temp_url_data_crw";


	url_red_fld(req_for_redirect,function(response){

res.redirect(response);

	});
})


});

});












function isrt_in_ana_db(req_data,req,callback){

	console.log(req_data);

id=req_data.con_id;
act=parseInt(req_data.act_flg);
ip_data=req_data.ip;
tbl_name=req_data.tbl_name;





const axios = require('axios');


	console.log(ip_data+"cccc");

axios.post("http://www.geoplugin.net/json.gp?ip="+ip_data).then(response => {


cnt=response.data.geoplugin_countryCode;
reg=response.data.geoplugin_regionCode;

var dt_tm = new Date().toISOString("en-US", {timeZone: "UTC"});


//console.log(dt_tm);


const social_conn = require("./confige/email_analysis.confige.js");

console.log('INSERT INTO `'+tbl_name+'` (id,act,cnt,act_date,reg) values ("'+id+'","'+act+'","'+cnt+'","'+dt_tm+'","'+reg+'")');



if(act!=undefined){

/*
sel_check_flg_data='select * from `'+tbl_name+'` where con_id="'+id+'" and act="'+act+'"';

social_conn.query(sel_check_flg_data, (err, results) => {

if(result.length!=0){

}
})
*/
social_conn.query('INSERT INTO `'+tbl_name+'` (id,act,cnt,act_date,reg) values ("'+id+'","'+act+'","'+cnt+'","'+dt_tm+'","'+reg+'")', (err, results) => {

if(err){
if (err['code']!='ER_DUP_ENTRY'){

	splt_data=tbl_name.split("#");

trg_auta_funct(act,splt_data[0],splt_data[1],id);
}

callback(req.params.flg_data);
}

	console.log("trigger contact id : "+id);

	splt_data=tbl_name.split("#");

trg_auta_funct(act,splt_data[0],splt_data[1],id);



console.log(tbl_name);
callback(req.params.flg_data);






});


	handleDisconnect(social_conn);
}else{


	callback(req.params.flg_data);



}




}).catch(error => {
    console.log(error);
  });




}



function handleDisconnect(connection) {
  connection.on('error', function(err) {
    if (!err.fatal) {
      return;
    }

    if (err.code !== 'PROTOCOL_CONNECTION_LOST') {
      throw err;
    }

    console.log('Re-connecting lost connection: ' + err.stack);

    connection = mysql.createConnection(connection.config);
    handleDisconnect(connection);
    connection.connect();
  });
}







function update_fld_of_db(req_data,callback){


tbl_name=req_data.tbl_name;
update_fld=req_data.update_fld;
update_tag=req_data.update_tag;
usr_id=req_data.con_id;



const contact_conn = require("./confige/contact.confige.js");




contact_conn.query('update `'+tbl_name+'` set `'+update_fld+'`="'+update_tag+'" where con_id="'+usr_id+'"', (err, results) => {


       if (err) {
      console.log("error: ", err);

    }else{


      console.log("update successfull");
    }






});



	handleDisconnect(contact_conn);

callback(0);

}









function url_red_fld(req_data,callback){



url_id=req_data.url_id;
match_fld=req_data.match_fld;
ret_fld=req_data.get_fld;
tbl_name=req_data.tbl_name;


 social_conn = require("./confige/camp_url_data.confige.js");



sel_query='SELECT * FROM `'+tbl_name+'` WHERE `'+match_fld+'`="'+url_id+'"';
console.log(sel_query);

social_conn.query(sel_query, (err, results) => {


console.log(results);

    var resultArray = Object.values(JSON.parse(JSON.stringify(results)))




       callback(resultArray[0].url)



});


handleDisconnect(social_conn)
//social_conn.end();

}
