
const mysql = require("mysql");

  HOST= "database-1.ctrrqd240l6m.us-east-2.rds.amazonaws.com";
  USER= "admin";
  PASSWORD= "Ravi91068";
  DB= "social_post";






// Create a connection to the database
const connection = mysql.createConnection({
  host: HOST,
  user: USER,
  password: PASSWORD,
  database: DB
});

// open the MySQL connection
connection.connect(error => {
  if (error) throw error;
  console.log("Successfully connected to the database.");
});

module.exports = connection;