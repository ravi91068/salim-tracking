const mysql = require("mysql");

  HOST= "automation.cqfl2ctd3vqp.us-east-2.rds.amazonaws.com";
  USER= "admin";
  PASSWORD= "Ravi91068";
  DB= "automation";





// Create a connection to the database
const connection = mysql.createConnection({
  host: HOST,
  user: USER,
  password: PASSWORD,
  database: DB
});

// open the MySQL connection
connection.connect(error => {
  if (error) throw error;
  console.log("Successfully connected to the database.");
});

module.exports = connection;
                  
